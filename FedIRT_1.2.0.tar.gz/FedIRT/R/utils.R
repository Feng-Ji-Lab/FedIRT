.fedirtClusterEnv <- new.env(parent=emptyenv())
