test_that("fedirt", {
  expect_equal(2 * 2, 4)
})
