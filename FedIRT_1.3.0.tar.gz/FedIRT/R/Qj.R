Qj = function(a, b) {
  return (1 - .fedirtClusterEnv$Pj(a, b))
}
