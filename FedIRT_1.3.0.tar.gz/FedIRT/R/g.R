g = function(x) {
  return (exp(-0.5 * x * x) / sqrt(2 * pi))
}
