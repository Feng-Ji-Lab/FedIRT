LA = function(a, b, index) {
  broadcast.multiplication(.fedirtClusterEnv$Lik(a,b,index), t(.fedirtClusterEnv$A))
}
