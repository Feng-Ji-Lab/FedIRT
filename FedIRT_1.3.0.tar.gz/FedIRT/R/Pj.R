Pj = function(a, b) {
  t = exp(-1 * broadcast.multiplication(a, broadcast.subtraction(b, t(.fedirtClusterEnv$X))))
  return (t / (1 + t))
}
