#' @noRd
utils::globalVariables(c("J", "K","getlogL_from_index","get_g_logL_from_index","Lik","Pj","parseQueryString","httpResponse","Discrimination","localdata","M","observe","read.csv","renderText","observeEvent","req","renderDataTable","renderPlot","renderPrint","Index","Difficulty","uiOutput","reactiveValues","renderUI"))
