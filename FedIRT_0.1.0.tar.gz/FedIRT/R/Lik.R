
Lik = function(a, b, index) {
  exp(.fedirtClusterEnv$log_Lik(a, b, index))
}
