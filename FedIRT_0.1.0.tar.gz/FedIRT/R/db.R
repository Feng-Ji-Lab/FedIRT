
db = function(a, b, index) {
  -1 * a * matrix(apply((.fedirtClusterEnv$rjk(a, b, index) - broadcast.multiplication(.fedirtClusterEnv$Pj(a, b), t(.fedirtClusterEnv$njk(a, b, index)))), c(1), sum))
}
